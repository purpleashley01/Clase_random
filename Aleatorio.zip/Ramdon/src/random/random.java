package random;

import java.util.*;


public class random {
	public static void main (String[] args) {
	
	Random aleatorio= new Random();
	
	
	int num= aleatorio.nextInt(501);
	
	System.out.println("El numero aleratorio es:"+ num);
	
	
	
	
	
	}
	
	
	

}
